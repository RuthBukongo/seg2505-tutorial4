package com.example.sqlite;

public class TestDatabase {
    //A remplir
    public UserDao getUser() {
        return null;
    }

    public void close() {

    }
}
