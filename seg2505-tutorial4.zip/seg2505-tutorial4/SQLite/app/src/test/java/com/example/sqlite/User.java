package com.example.sqlite;

public class User {
    private String name;
    public void setName (String name){
        this.name=name;
    }
}
