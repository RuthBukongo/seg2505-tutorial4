# seg2505-tutorial4
uOttawa - 2024-2025 - SEG2505A - Tutoriel 4 - SQLite - V1.0
Il s'agit de l'ajout de la base de donnée SQLite à un porjet android studio code

-Le tutoriel réalisé:
     En Java (obligatoire)
 .Enregistrer des données avec SQLite | Android Developers

# Lien vers le dépot github

https://github.com/Bruno025/seg2505-tutorial4

# N.B:
Problème rencontré avec la partie "Pratique SQL" du tutoriel, dû au mauvais fonctionnement du projet de démarrage téléchargé depuis github: https://github.com/google-developer-training/android-basics-kotlin-sql-basics-app/tree/compose
